document.addEventListener("DOMContentLoaded", function () {

  const form = document.getElementById("requestForm");

  if (!form) {
    return;
  }

  form.addEventListener("submit", function (event) {

    event.preventDefault();


    /* =========================
       GET FORM DATA
    ========================= */

    const name =
      document.getElementById("clientName").value.trim();

    const phone =
      document.getElementById("clientPhone").value.trim();

    const type =
      document.getElementById("projectType").value;

    const service =
      document.getElementById("serviceType").value;

    const area =
      document.getElementById("projectArea").value.trim();

    const size =
      document.getElementById("projectSize").value.trim();

    const details =
      document.getElementById("projectDetails").value.trim();


    /* =========================
       WHATSAPP MESSAGE
    ========================= */

    const message = `
طلب معاينة جديد - Al-Sharqawi

الاسم: ${name}

رقم الهاتف: ${phone}

نوع المشروع: ${type}

الخدمة المطلوبة: ${service}

المنطقة / العنوان: ${area}

المساحة: ${size || "غير محددة"}

تفاصيل المشروع:
${details || "لا توجد تفاصيل إضافية"}

نشكركم للتواصل مع Al-Sharqawi Group.
`;


    /* =========================
       WHATSAPP NUMBER
    ========================= */

    const whatsappNumber = "201033910370";


    /* =========================
       CREATE WHATSAPP URL
    ========================= */

    const whatsappURL =
      "https://wa.me/" +
      whatsappNumber +
      "?text=" +
      encodeURIComponent(message);


    /* =========================
       OPEN WHATSAPP
    ========================= */

    window.open(whatsappURL, "_blank");

  });

});